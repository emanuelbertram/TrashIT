package com.example.trashit.model

data class User(
    val email: String,
    val displayName: String)